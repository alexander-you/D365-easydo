/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ContactCenterPane/index.ts"
/*!************************************!*\
  !*** ./ContactCenterPane/index.ts ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ContactCenterPane: () => (/* binding */ ContactCenterPane)\n/* harmony export */ });\n/**\n * EasyDo.ContactCenterPane\n *\n * A thin standalone PCF control that hosts the contact-center productivity-pane\n * web resource (alex_/html/contactCenterPane.html) inside an iframe. It exists\n * only because a custom productivity tool must be a Control or a Custom Page —\n * an HTML web resource cannot be registered directly. The web resource is served\n * from the org domain, so it is same-origin with the app and keeps native access\n * to Xrm.WebApi and the Omnichannel client API through the frame chain.\n */\nclass ContactCenterPane {\n  constructor() {\n    this._src = \"\";\n  }\n  init(context, _notifyOutputChanged, _state, container) {\n    this._container = container;\n    this._container.classList.add(\"edo-cc-pane-host\");\n    this._iframe = document.createElement(\"iframe\");\n    this._iframe.className = \"edo-cc-pane-frame\";\n    this._iframe.setAttribute(\"title\", \"easydo Contact Center\");\n    this._iframe.setAttribute(\"frameborder\", \"0\");\n    this._iframe.setAttribute(\"allow\", \"clipboard-read; clipboard-write\");\n    this._container.appendChild(this._iframe);\n    this._src = this.buildSrc(context);\n    this._iframe.src = this._src;\n  }\n  updateView(context) {\n    var next = this.buildSrc(context);\n    if (next && next !== this._src) {\n      this._src = next;\n      this._iframe.src = next;\n    }\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    if (this._iframe) {\n      this._iframe.src = \"about:blank\";\n    }\n  }\n  /** Resolve the absolute URL of the hosted web resource. */\n  buildSrc(context) {\n    var wr = context.parameters.webResource && context.parameters.webResource.raw && context.parameters.webResource.raw.trim() || ContactCenterPane.DEFAULT_WEB_RESOURCE;\n    var base = this.getClientUrl(context).replace(/\\/+$/, \"\");\n    return base + \"/WebResources/\" + wr;\n  }\n  /**\n   * Best-effort org client URL. context.page.getClientUrl is the supported PCF\n   * accessor; fall back to the global Xrm context (present in the model-driven\n   * shell) and finally to a relative path.\n   */\n  getClientUrl(context) {\n    try {\n      var page = context.page;\n      if (page && typeof page.getClientUrl === \"function\") {\n        var url = page.getClientUrl();\n        if (url) {\n          return url;\n        }\n      }\n    } catch (e) {\n      /* ignore */\n    }\n    try {\n      var xrm = window.Xrm;\n      var getGlobalContext = xrm && xrm.Utility && xrm.Utility.getGlobalContext;\n      if (typeof getGlobalContext === \"function\") {\n        var ctx = getGlobalContext();\n        if (ctx && typeof ctx.getClientUrl === \"function\") {\n          var _url = ctx.getClientUrl();\n          if (_url) {\n            return _url;\n          }\n        }\n      }\n    } catch (e) {\n      /* ignore */\n    }\n    return \"\";\n  }\n}\nContactCenterPane.DEFAULT_WEB_RESOURCE = \"alex_/html/contactCenterPane.html\";\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ContactCenterPane/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ContactCenterPane/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('EasyDo.ContactCenterPane', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ContactCenterPane);
} else {
	var EasyDo = EasyDo || {};
	EasyDo.ContactCenterPane = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ContactCenterPane;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}